
//este archivo contiene funciones en c�digo JavaScritp
function mostrarMensaje1(){
alert('Has hecho click sobre la imagen');
}

function mostrarMensaje2(){
alert('Has hecho click sobre el parrafo inferior');
}

function mostrarNombre(name, lastName){
alert('Hola: ' + name + ' ' +lastName);
}