﻿function mostrarAlert() {
    alert('Este mensaje se ha mostrado utilizando código JavaScript en un archivo externo');
}