var slideIndex = 1;
var slides = document.getElementsByClassName("mySlides");
showSlides(slideIndex);

// Next/previous controls
function plusSlides(n) {
  slideIndex += n;	
  showSlides(slideIndex);
}

// Thumbnail image controls
function currentSlide(n) {
  showSlides(slideIndex = n);
}

function showSlides(n) {
  var i;
  
 
  if (n > slides.length) {n = 1; slideIndex = 1;}
  if (n < 1) {slideIndex = slides.length; n= slideIndex;}
  for (i = 0; i < slides.length; i++) {
      slides[i].style.display = "none";
  }
 
  slides[n-1].style.display = "block";
  
}
